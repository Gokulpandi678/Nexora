# Incident Tracker

Employees report incidents; the app finds similar past incidents, lets the reporter link to one (notifying its original owner) or keep it as new, and stores multiple solutions per issue with a QA checklist and verified/unverified tracking.

**Stack:** Next.js 15 (App Router) · TypeScript · Prisma 6 · PostgreSQL (Supabase) · Tailwind 3 · Resend · Zustand

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy `.env.example` to `.env` and fill it in. Prisma CLI reads `.env`, not `.env.local`.
   - `DATABASE_URL`: the Supabase **pooled** connection (port 6543). Keep `?pgbouncer=true`.
   - `DIRECT_URL`: the Supabase **direct/session** connection (port 5432). Migrations use this one.
   - `RESEND_API_KEY` / `EMAIL_FROM`: optional. If they're unset, recurrence notifications are logged to the server console instead of emailed.

   > ⚠️ **Variables set in your shell override `.env`.** If `DATABASE_URL` is already set globally on your machine (for another project), Prisma and the app will use that value instead. Check with `echo $DATABASE_URL` (bash) or `$env:DATABASE_URL` (PowerShell) before running migrations or the seed.

3. Create the schema. This also creates the full-text GIN index:
   ```bash
   npx prisma migrate deploy
   ```
4. Optional: load sample data. **This deletes all existing incidents first.**
   ```bash
   npm run db:seed
   ```
5. Run:
   ```bash
   npm run dev
   ```
   Then open http://localhost:3000.

## How matching works

`searchSimilarIncidents` in `lib/db.ts` uses Postgres full-text search (`to_tsvector` / `ts_rank_cd`, stemmed English) over title, description and symptoms, with OR semantics across the report's keywords:

- A candidate needs **at least 2 distinct matching keywords**, or **1 keyword plus a shared affected system**. This filters out incidental single-word hits.
- Shared affected systems boost the score.
- Each match shows its shared keywords, how many times it has recurred, and its known fixes. Verified fixes are listed first.

Linking as **Same issue** sets `linkedToId` to the root of the chain, so recurrences group under one original. **Related** only records a `MatchLink`. Notifications are deduplicated through `NotificationLog`.

## API

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/incidents/create` | Create an incident; returns `{ incident, similarIncidents }` |
| POST | `/api/incidents/link` | Link a new incident to an earlier one and notify its owner |
| POST | `/api/incidents/resolve` | Add a solution (with QA checks); optionally mark the incident resolved |
| GET | `/api/incidents/search?q=&status=&severity=&system=` | List and filter incidents |
| GET / PATCH | `/api/incidents/[id]` | Get full details / change status |
| PATCH | `/api/solutions/[id]` | Mark a solution `VERIFIED` / `UNVERIFIED` |
| GET | `/api/incidents/stats` | Data for the Patterns dashboard |

All write routes validate input and return `400` with a message for invalid input.

## Project layout

```
app/                 pages + API routes
components/          IncidentForm, IncidentList, IncidentDetail, ResolutionForm, PatternsDashboard, ui
hooks/useIncidents.ts  data hooks + Zustand stores (filters, remembered reporter)
lib/                 db/search, email, validation, constants, design tokens, types
prisma/              schema, init migration (with FTS index), seed
```
