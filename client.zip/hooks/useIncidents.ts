'use client'

import { useCallback, useEffect, useState } from 'react'
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { IncidentDetail, IncidentSummary, Stats } from '@/lib/types'

export async function apiFetch<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...init?.headers }
  })
  const data = await res.json().catch(() => null)
  if (!res.ok) throw new Error(data?.error ?? `Request failed (${res.status})`)
  return data as T
}

/* ---------- Shared client state ---------- */

interface Filters {
  q: string
  status: string
  severity: string
  system: string
}

interface FilterStore extends Filters {
  setFilter: <K extends keyof Filters>(key: K, value: Filters[K]) => void
  reset: () => void
}

const EMPTY_FILTERS: Filters = { q: '', status: '', severity: '', system: '' }

export const useIncidentFilters = create<FilterStore>(set => ({
  ...EMPTY_FILTERS,
  setFilter: (key, value) => set({ [key]: value } as Partial<Filters>),
  reset: () => set(EMPTY_FILTERS)
}))

interface ReporterStore {
  name: string
  email: string
  setReporter: (name: string, email: string) => void
}

/** Remembers who is reporting so the name/email fields are prefilled next time. */
export const useReporter = create<ReporterStore>()(
  persist(set => ({ name: '', email: '', setReporter: (name, email) => set({ name, email }) }), {
    name: 'incident-tracker-reporter',
    // Rehydrated from an effect (see useRememberedReporter) to avoid SSR hydration mismatches
    skipHydration: true
  })
)

export function useRememberedReporter() {
  const reporter = useReporter()
  useEffect(() => {
    useReporter.persist.rehydrate()
  }, [])
  return reporter
}

/* ---------- Queries ---------- */

function useQuery<T>(url: string | null, delay = 0) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(Boolean(url))
  const [error, setError] = useState<string | null>(null)
  const [version, setVersion] = useState(0)

  useEffect(() => {
    if (!url) return
    const controller = new AbortController()
    setLoading(true)
    const timer = setTimeout(() => {
      apiFetch<T>(url, { signal: controller.signal })
        .then(result => {
          setData(result)
          setError(null)
        })
        .catch(err => {
          if (!controller.signal.aborted) setError(err.message)
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false)
        })
    }, delay)
    return () => {
      clearTimeout(timer)
      controller.abort()
    }
  }, [url, delay, version])

  const refresh = useCallback(() => setVersion(v => v + 1), [])
  return { data, loading, error, refresh, setData }
}

export function useIncidents() {
  const { q, status, severity, system } = useIncidentFilters()
  const params = new URLSearchParams()
  if (q.trim()) params.set('q', q.trim())
  if (status) params.set('status', status)
  if (severity) params.set('severity', severity)
  if (system) params.set('system', system)

  // Debounce only while typing; dropdown changes apply immediately
  const { data, ...rest } = useQuery<IncidentSummary[]>(`/api/incidents/search?${params}`, q ? 250 : 0)
  return { incidents: data ?? [], ...rest }
}

export function useIncident(id: string) {
  const { data, ...rest } = useQuery<IncidentDetail>(`/api/incidents/${encodeURIComponent(id)}`)
  return { incident: data, ...rest }
}

export function useStats() {
  const { data, ...rest } = useQuery<Stats>('/api/incidents/stats')
  return { stats: data, ...rest }
}
