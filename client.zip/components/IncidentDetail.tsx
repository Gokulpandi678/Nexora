'use client'

import Link from 'next/link'
import { useState, useTransition } from 'react'
import { format } from 'date-fns'
import { QA_CHECKLIST, STATUSES, STATUS_LABEL } from '@/lib/constants'
import type { IncidentSummary, Solution } from '@/lib/types'
import { apiFetch, useIncident } from '@/hooks/useIncidents'
import ResolutionForm from '@/components/ResolutionForm'
import {
  EmptyState, ErrorNotice, formatMinutes, IdTag, Segmented, SeverityBadge, SkeletonCards,
  SolutionStatusBadge, StatusBadge, SystemTag, timeAgo
} from '@/components/ui'

const EFFICIENCY_BADGE: Record<string, [string, string]> = {
  HIGH: ['badge-success', 'Permanent fix'],
  MEDIUM: ['badge-info', 'Partial fix'],
  LOW: ['badge-warning', 'Workaround']
}

export default function IncidentDetail({ id }: { id: string }) {
  const { incident, loading, error, refresh, setData } = useIncident(id)
  const [adding, setAdding] = useState(false)
  const [statusError, setStatusError] = useState<string | null>(null)
  const [isPending, startTransition] = useTransition()

  if (error && !incident) {
    return error === 'Incident not found'
      ? <EmptyState title="Incident not found">It may have been removed. <Link href="/?tab=view" className="text-[#7dd3fc] underline">Back to all incidents</Link></EmptyState>
      : <ErrorNotice message={error} onRetry={refresh} />
  }
  if (loading && !incident) return <SkeletonCards count={3} />
  if (!incident) return null

  const changeStatus = (status: string) => {
    setStatusError(null)
    const previous = incident
    setData({ ...incident, status }) // optimistic
    startTransition(async () => {
      try {
        await apiFetch(`/api/incidents/${incident.id}`, { method: 'PATCH', body: JSON.stringify({ status }) })
        refresh()
      } catch (err) {
        setData(previous)
        setStatusError((err as Error).message)
      }
    })
  }

  // Fixes from the original incident are the most useful thing on a recurrence
  const inheritedSolutions = incident.linkedTo?.solutions ?? []
  const recurrences = incident.matchedFrom

  return (
    <article className="animate-in flex flex-col gap-6" aria-labelledby="incident-title">
      <header className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <SeverityBadge severity={incident.severity} long />
          <StatusBadge status={incident.status} />
          <IdTag id={incident.id} />
        </div>
        <h1 id="incident-title" className="text-xl font-bold sm:text-2xl">{incident.title}</h1>
        <p className="text-xs text-[#94a3b8]">
          Reported by <span className="font-medium text-[#cbd5e1]">{incident.createdBy}</span>{' '}
          (<a href={`mailto:${incident.email}`} className="hover:text-[#7dd3fc] hover:underline">{incident.email}</a>)
          {' · '}
          <time dateTime={incident.createdAt} title={format(new Date(incident.createdAt), 'PPpp')}>{timeAgo(incident.createdAt)}</time>
          {incident.resolvedAt && (
            <> · resolved <time dateTime={incident.resolvedAt}>{timeAgo(incident.resolvedAt)}</time></>
          )}
        </p>
        <div className="flex flex-col gap-1.5 sm:flex-row sm:items-center sm:gap-3">
          <span className="text-xs font-semibold text-[#cbd5e1]">Status</span>
          <Segmented
            label="Incident status"
            options={STATUSES}
            value={incident.status as (typeof STATUSES)[number]}
            onChange={changeStatus}
            renderLabel={s => STATUS_LABEL[s]}
          />
          {isPending && <span className="text-xs text-[#94a3b8]" role="status">Saving…</span>}
        </div>
        {statusError && <ErrorNotice message={statusError} />}
      </header>

      {incident.linkedTo && (
        <div className="card card-compact border-[#8b5cf6]/50 bg-[#8b5cf6]/10" role="note">
          <p className="text-[13px] text-[#cbd5e1]">
            <span className="font-semibold text-[#c4b5fd]">↻ Recurrence of </span>
            <Link href={`/incidents/${incident.linkedTo.id}`} className="font-semibold text-[#f1f5f9] hover:text-[#7dd3fc] hover:underline">
              {incident.linkedTo.title}
            </Link>
            <span className="text-[#94a3b8]"> — first reported by {incident.linkedTo.createdBy} {timeAgo(incident.linkedTo.createdAt)}</span>
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_280px]">
        <div className="flex flex-col gap-4">
          <section className="card">
            <h2 className="mb-1.5 text-xs font-semibold text-[#94a3b8]">Description</h2>
            <p className="prose-compact text-[13px]">{incident.description}</p>
            <h2 className="mb-1.5 mt-4 text-xs font-semibold text-[#94a3b8]">Observable symptoms</h2>
            <p className="prose-compact text-[13px]">{incident.symptoms}</p>
          </section>

          {inheritedSolutions.length > 0 && (
            <section aria-labelledby="inherited-heading">
              <h2 id="inherited-heading" className="mb-1 text-sm font-semibold">Fixes from the original incident</h2>
              <p className="mb-3 text-xs text-[#94a3b8]">If one works here, mark it verified so it ranks first next time.</p>
              <div className="flex flex-col gap-3">
                {inheritedSolutions.map(s => <SolutionCard key={s.id} solution={s} onChanged={refresh} />)}
              </div>
            </section>
          )}

          <section aria-labelledby="solutions-heading">
            <div className="mb-3 flex items-center justify-between gap-3">
              <h2 id="solutions-heading" className="section-title">
                Solutions <span className="text-sm font-medium text-[#94a3b8]">({incident.solutions.length})</span>
              </h2>
              {!adding && (
                <button type="button" className="btn btn-primary btn-sm" onClick={() => setAdding(true)}>
                  + Add solution
                </button>
              )}
            </div>

            <div className="flex flex-col gap-3">
              {adding && (
                <ResolutionForm
                  incidentId={incident.id}
                  alreadyResolved={incident.status === 'RESOLVED'}
                  onCancel={() => setAdding(false)}
                  onSaved={() => {
                    setAdding(false)
                    refresh()
                  }}
                />
              )}
              {incident.solutions.map(s => <SolutionCard key={s.id} solution={s} onChanged={refresh} />)}
              {incident.solutions.length === 0 && !adding && (
                <EmptyState title="No solution recorded yet">
                  Once this is fixed, add what worked — it becomes the suggested fix when the issue comes back.
                </EmptyState>
              )}
            </div>
          </section>
        </div>

        <aside className="flex flex-col gap-4">
          <section className="card card-compact">
            <h2 className="mb-2 text-xs font-semibold text-[#94a3b8]">Affected systems</h2>
            {incident.affectedSystems.length ? (
              <div className="flex flex-wrap gap-1.5">
                {incident.affectedSystems.map(s => <SystemTag key={s} system={s} />)}
              </div>
            ) : (
              <p className="text-xs text-[#94a3b8]">None specified</p>
            )}
          </section>

          <section className="card card-compact" aria-labelledby="recurrence-heading">
            <h2 id="recurrence-heading" className="mb-2 text-xs font-semibold text-[#94a3b8]">
              Reported again {recurrences.length > 0 && <span className="badge badge-warning ml-1">{recurrences.length}×</span>}
            </h2>
            {recurrences.length === 0 ? (
              <p className="text-xs text-[#94a3b8]">No later incidents have been linked to this one.</p>
            ) : (
              <ul className="flex flex-col gap-2">
                {recurrences.map(m => (
                  <li key={m.id}>
                    <RelatedLink incident={m.newIncident} meta={`${m.matchType === 'SAME' ? 'Same issue' : 'Related'} · ${timeAgo(m.createdAt)}`} />
                    {m.notes && <p className="mt-0.5 line-clamp-2 pl-2 text-[11px] italic text-[#94a3b8]">“{m.notes}”</p>}
                  </li>
                ))}
              </ul>
            )}
          </section>

          {incident.matchedAs.length > 0 && (
            <section className="card card-compact">
              <h2 className="mb-2 text-xs font-semibold text-[#94a3b8]">Matched to earlier incidents</h2>
              <ul className="flex flex-col gap-2">
                {incident.matchedAs.map(m => (
                  <li key={m.id}>
                    <RelatedLink incident={m.originalIncident} meta={m.matchType === 'SAME' ? 'Same issue' : 'Related'} />
                  </li>
                ))}
              </ul>
            </section>
          )}
        </aside>
      </div>
    </article>
  )
}

function RelatedLink({ incident, meta }: { incident: IncidentSummary; meta: string }) {
  return (
    <Link href={`/incidents/${incident.id}`} className="-mx-1 block rounded px-1 py-1 transition-colors hover:bg-[#334155]">
      <span className="flex items-center gap-1.5">
        <SeverityBadge severity={incident.severity} />
        <span className="truncate text-[13px] text-[#f1f5f9]">{incident.title}</span>
      </span>
      <span className="text-[11px] text-[#94a3b8]">{incident.createdBy} · {meta}</span>
    </Link>
  )
}

function SolutionCard({ solution, onChanged }: { solution: Solution; onChanged: () => void }) {
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [badgeClass, badgeLabel] = EFFICIENCY_BADGE[solution.efficiency] ?? ['badge-neutral', solution.efficiency]
  const missingChecks = QA_CHECKLIST.filter(c => !solution.qaChecks.includes(c.id))
  const verified = solution.status === 'VERIFIED'

  const toggleVerified = () => {
    setError(null)
    startTransition(async () => {
      try {
        await apiFetch(`/api/solutions/${solution.id}`, {
          method: 'PATCH',
          body: JSON.stringify({ status: verified ? 'UNVERIFIED' : 'VERIFIED' })
        })
        onChanged()
      } catch (err) {
        setError((err as Error).message)
      }
    })
  }

  return (
    <div className={`card ${verified ? 'border-[#10b981]/50' : ''}`}>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          <SolutionStatusBadge status={solution.status} />
          <span className={`badge ${badgeClass}`}>{badgeLabel}</span>
          <span className="badge badge-neutral">⏱ {formatMinutes(solution.timeToFix)}</span>
        </div>
        <button type="button" className={`btn btn-sm ${verified ? 'btn-ghost' : 'btn-secondary'}`} onClick={toggleVerified} disabled={isPending}>
          {isPending ? 'Saving…' : verified ? 'Unmark verified' : 'It worked — mark verified'}
        </button>
      </div>

      <dl className="flex flex-col gap-3 text-[13px]">
        <div>
          <dt className="mb-0.5 text-xs font-semibold text-[#94a3b8]">Root cause</dt>
          <dd className="prose-compact">{solution.rootCause}</dd>
        </div>
        <div>
          <dt className="mb-0.5 text-xs font-semibold text-[#94a3b8]">What fixed it</dt>
          <dd className="prose-compact text-[#f1f5f9]">{solution.approach}</dd>
        </div>
        <div>
          <dt className="mb-0.5 text-xs font-semibold text-[#94a3b8]">When to use it</dt>
          <dd className="prose-compact">{solution.useCaseNotes}</dd>
        </div>
      </dl>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[#475569] pt-2.5 text-[11px] text-[#94a3b8]">
        <span>By {solution.solvedBy} · {timeAgo(solution.solvedAt)}</span>
        {missingChecks.length === 0 ? (
          <span className="text-[#6ee7b7]">✓ QA checklist complete</span>
        ) : (
          <span className="text-[#fcd34d]" title={missingChecks.map(c => `• ${c.label}`).join('\n')}>
            QA {QA_CHECKLIST.length - missingChecks.length}/{QA_CHECKLIST.length} checked
            <span className="sr-only">. Not checked: {missingChecks.map(c => c.label).join('; ')}</span>
          </span>
        )}
      </div>
      {error && <div className="mt-2"><ErrorNotice message={error} /></div>}
    </div>
  )
}
