'use client'

import { useRouter } from 'next/navigation'
import { useState } from 'react'
import clsx from 'clsx'
import IncidentForm from '@/components/IncidentForm'
import IncidentList from '@/components/IncidentList'
import PatternsDashboard from '@/components/PatternsDashboard'
import AppHeader from '@/components/AppHeader'
import { TABS, type TabId } from '@/lib/constants'

export default function Dashboard({ initialTab }: { initialTab: TabId }) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<TabId>(initialTab)

  const selectTab = (tab: TabId) => {
    setActiveTab(tab)
    router.replace(tab === 'report' ? '/' : `/?tab=${tab}`, { scroll: false })
  }

  const onKeyDown = (e: React.KeyboardEvent, index: number) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return
    const next = TABS[(index + (e.key === 'ArrowRight' ? 1 : TABS.length - 1)) % TABS.length]
    selectTab(next.id)
    document.getElementById(`tab-${next.id}`)?.focus()
  }

  return (
    <div className="mx-auto max-w-[1200px] pb-10 pt-5">
      <AppHeader />

      <div role="tablist" aria-label="Sections" className="mb-6 flex gap-1 overflow-x-auto border-b border-[#475569] px-4 sm:gap-2 sm:px-6">
        {TABS.map((tab, i) => (
          <button
            key={tab.id}
            id={`tab-${tab.id}`}
            role="tab"
            type="button"
            aria-selected={activeTab === tab.id}
            aria-controls={`panel-${tab.id}`}
            tabIndex={activeTab === tab.id ? 0 : -1}
            onClick={() => selectTab(tab.id)}
            onKeyDown={e => onKeyDown(e, i)}
            className={clsx(
              '-mb-px whitespace-nowrap border-b-2 px-3 py-3 text-[13px] font-semibold transition-colors sm:px-4',
              activeTab === tab.id
                ? 'border-[#0ea5e9] text-[#0ea5e9]'
                : 'border-transparent text-[#94a3b8] hover:text-[#cbd5e1]'
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div id={`panel-${activeTab}`} role="tabpanel" aria-labelledby={`tab-${activeTab}`} className="px-4 sm:px-6">
        {activeTab === 'report' && <IncidentForm />}
        {activeTab === 'view' && <IncidentList />}
        {activeTab === 'patterns' && <PatternsDashboard />}
      </div>
    </div>
  )
}
