import clsx from 'clsx'
import { formatDistanceToNowStrict } from 'date-fns'
import { SEVERITY_LABEL, STATUS_LABEL } from '@/lib/constants'

const SEVERITY_CLASS: Record<string, string> = {
  P1: 'badge-danger',
  P2: 'badge-warning',
  P3: 'badge-info'
}

const STATUS_CLASS: Record<string, string> = {
  OPEN: 'badge-info',
  INVESTIGATING: 'badge-warning',
  RESOLVED: 'badge-success'
}

export function SeverityBadge({ severity, long = false }: { severity: string; long?: boolean }) {
  return (
    <span className={clsx('badge', SEVERITY_CLASS[severity] ?? 'badge-neutral')} title={SEVERITY_LABEL[severity]}>
      {long ? SEVERITY_LABEL[severity] ?? severity : severity}
    </span>
  )
}

export function StatusBadge({ status }: { status: string }) {
  return (
    <span className={clsx('badge', STATUS_CLASS[status] ?? 'badge-neutral')}>
      {status === 'RESOLVED' ? '✓ ' : status === 'INVESTIGATING' ? '◐ ' : '○ '}
      {STATUS_LABEL[status] ?? status}
    </span>
  )
}

export function SolutionStatusBadge({ status }: { status: string }) {
  return status === 'VERIFIED'
    ? <span className="badge badge-success">✓ Verified</span>
    : <span className="badge badge-neutral">Unverified</span>
}

export function SystemTag({ system, highlight = false }: { system: string; highlight?: boolean }) {
  return <span className={clsx('badge', highlight ? 'badge-violet' : 'badge-neutral')}>{system}</span>
}

export function IdTag({ id }: { id: string }) {
  return <span className="font-mono text-[11px] text-[#94a3b8]">#{id.slice(-7)}</span>
}

export function timeAgo(date: string | Date) {
  return formatDistanceToNowStrict(new Date(date), { addSuffix: true })
}

export function formatMinutes(minutes: number) {
  if (minutes < 60) return `${minutes} min`
  const h = Math.floor(minutes / 60)
  const m = minutes % 60
  if (h < 24) return m ? `${h}h ${m}m` : `${h}h`
  const d = Math.floor(h / 24)
  return h % 24 ? `${d}d ${h % 24}h` : `${d}d`
}

export function ErrorNotice({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="card card-compact flex items-center justify-between gap-3 border-[#ef4444]/60 bg-[#ef4444]/10">
      <p className="text-[13px] text-[#fca5a5]">{message}</p>
      {onRetry && (
        <button type="button" className="btn btn-secondary btn-sm shrink-0" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  )
}

export function EmptyState({ title, children }: { title: string; children?: React.ReactNode }) {
  return (
    <div className="card flex flex-col items-center gap-2 py-10 text-center">
      <p className="text-sm font-semibold text-[#f1f5f9]">{title}</p>
      {children && <div className="max-w-[48ch] text-[13px] text-[#94a3b8]">{children}</div>}
    </div>
  )
}

export function SkeletonCards({ count = 3 }: { count?: number }) {
  return (
    <div className="flex flex-col gap-3" aria-busy="true" aria-label="Loading">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="card pulse-soft h-[84px] bg-[#1e293b]/70" />
      ))}
    </div>
  )
}

export function Segmented<T extends string>({
  label,
  options,
  value,
  onChange,
  renderLabel
}: {
  label: string
  options: readonly T[]
  value: T
  onChange: (value: T) => void
  renderLabel?: (value: T) => React.ReactNode
}) {
  return (
    <div role="radiogroup" aria-label={label} className="flex flex-wrap gap-2">
      {options.map(option => (
        <button
          key={option}
          type="button"
          role="radio"
          aria-checked={value === option}
          className="chip min-w-[56px]"
          onClick={() => onChange(option)}
        >
          {renderLabel ? renderLabel(option) : option}
        </button>
      ))}
    </div>
  )
}
