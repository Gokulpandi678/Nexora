'use client'

import Link from 'next/link'
import { SEVERITIES, SEVERITY_LABEL, STATUSES, STATUS_LABEL, SYSTEM_OPTIONS } from '@/lib/constants'
import { useIncidentFilters, useIncidents } from '@/hooks/useIncidents'
import type { IncidentSummary } from '@/lib/types'
import { EmptyState, ErrorNotice, IdTag, SeverityBadge, SkeletonCards, StatusBadge, SystemTag, timeAgo } from '@/components/ui'

export default function IncidentList() {
  const filters = useIncidentFilters()
  const { incidents, loading, error, refresh } = useIncidents()
  const hasFilters = Boolean(filters.q || filters.status || filters.severity || filters.system)

  return (
    <section aria-labelledby="list-heading">
      <h2 id="list-heading" className="sr-only">All incidents</h2>

      <div className="mb-4 grid grid-cols-1 gap-2 sm:grid-cols-[1fr_auto_auto_auto]">
        <div className="relative">
          <label htmlFor="incident-search" className="sr-only">Search incidents</label>
          <input
            id="incident-search"
            type="search"
            className="input pl-8"
            placeholder="Search title, symptoms, reporter…"
            value={filters.q}
            onChange={e => filters.setFilter('q', e.target.value)}
          />
          <svg aria-hidden="true" viewBox="0 0 20 20" className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 fill-[#94a3b8]">
            <path d="M8.5 3a5.5 5.5 0 014.38 8.82l3.65 3.65-1.06 1.06-3.65-3.65A5.5 5.5 0 118.5 3zm0 1.5a4 4 0 100 8 4 4 0 000-8z" />
          </svg>
        </div>
        <FilterSelect
          label="Status"
          value={filters.status}
          onChange={v => filters.setFilter('status', v)}
          options={STATUSES.map(s => [s, STATUS_LABEL[s]])}
        />
        <FilterSelect
          label="Severity"
          value={filters.severity}
          onChange={v => filters.setFilter('severity', v)}
          options={SEVERITIES.map(s => [s, SEVERITY_LABEL[s]])}
        />
        <FilterSelect
          label="System"
          value={filters.system}
          onChange={v => filters.setFilter('system', v)}
          options={SYSTEM_OPTIONS.map(s => [s, s])}
        />
      </div>

      <div className="mb-3 flex min-h-[24px] items-center justify-between text-xs text-[#94a3b8]" aria-live="polite">
        <span>{loading ? 'Loading…' : `${incidents.length} incident${incidents.length === 1 ? '' : 's'}`}</span>
        {hasFilters && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={filters.reset}>Clear filters</button>
        )}
      </div>

      {error ? (
        <ErrorNotice message={error} onRetry={refresh} />
      ) : loading && incidents.length === 0 ? (
        <SkeletonCards />
      ) : incidents.length === 0 ? (
        <EmptyState title={hasFilters ? 'No incidents match these filters' : 'No incidents yet'}>
          {hasFilters ? 'Try a broader search or clear the filters.' : 'Reported incidents will show up here.'}
        </EmptyState>
      ) : (
        <ul className="flex flex-col gap-3">
          {incidents.map(incident => (
            <li key={incident.id}>
              <IncidentRow incident={incident} />
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}

function FilterSelect({
  label,
  value,
  onChange,
  options
}: {
  label: string
  value: string
  onChange: (value: string) => void
  options: [string, string][]
}) {
  return (
    <select aria-label={label} className="input sm:w-auto" value={value} onChange={e => onChange(e.target.value)}>
      <option value="">All {label.toLowerCase()}</option>
      {options.map(([v, text]) => (
        <option key={v} value={v}>{text}</option>
      ))}
    </select>
  )
}

function IncidentRow({ incident }: { incident: IncidentSummary }) {
  const recurrences = incident._count?.matchedFrom ?? 0
  const verified = incident.solutions.filter(s => s.status === 'VERIFIED').length

  return (
    <Link href={`/incidents/${incident.id}`} className="card card-interactive card-compact block">
      <div className="mb-1 flex items-start justify-between gap-3">
        <h3 className="min-w-0 text-sm font-semibold text-[#f1f5f9]">{incident.title}</h3>
        <div className="flex shrink-0 gap-1.5">
          <SeverityBadge severity={incident.severity} />
          <StatusBadge status={incident.status} />
        </div>
      </div>
      <p className="mb-2 line-clamp-1 max-w-[80ch] text-xs text-[#94a3b8]">{incident.symptoms}</p>
      <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-[#94a3b8]">
        <IdTag id={incident.id} />
        <span>· {incident.createdBy} · {timeAgo(incident.createdAt)}</span>
        {incident.affectedSystems.map(s => <SystemTag key={s} system={s} />)}
        {incident.solutions.length > 0 && (
          <span className="badge badge-success">
            {incident.solutions.length} fix{incident.solutions.length === 1 ? '' : 'es'}
            {verified > 0 && ` · ${verified} verified`}
          </span>
        )}
        {recurrences > 0 && <span className="badge badge-warning">↻ {recurrences}× recurred</span>}
        {incident.linkedToId && <span className="badge badge-violet">Recurrence</span>}
      </div>
    </Link>
  )
}
