'use client'

import { useEffect, useState, useTransition } from 'react'
import { EFFICIENCIES, QA_CHECKLIST } from '@/lib/constants'
import { apiFetch, useRememberedReporter } from '@/hooks/useIncidents'
import { ErrorNotice, Segmented } from '@/components/ui'

const TIME_PRESETS = [15, 30, 60, 120, 240] as const

const EFFICIENCY_LABEL: Record<string, string> = {
  LOW: 'Workaround',
  MEDIUM: 'Partial fix',
  HIGH: 'Permanent fix'
}

interface Props {
  incidentId: string
  alreadyResolved: boolean
  onSaved: () => void
  onCancel: () => void
}

export default function ResolutionForm({ incidentId, alreadyResolved, onSaved, onCancel }: Props) {
  const reporter = useRememberedReporter()
  const [form, setForm] = useState({
    rootCause: '',
    approach: '',
    timeToFix: '',
    efficiency: 'MEDIUM' as (typeof EFFICIENCIES)[number],
    useCaseNotes: '',
    solvedBy: ''
  })
  const [qaChecks, setQaChecks] = useState<string[]>([])
  const [resolve, setResolve] = useState(!alreadyResolved)
  const [error, setError] = useState<string | null>(null)
  const [isPending, startTransition] = useTransition()

  useEffect(() => {
    if (reporter.name) setForm(prev => (prev.solvedBy ? prev : { ...prev, solvedBy: reporter.name }))
  }, [reporter.name])

  const update = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) =>
    setForm(prev => ({ ...prev, [key]: value }))

  const toggleCheck = (id: string) =>
    setQaChecks(prev => (prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]))

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    startTransition(async () => {
      try {
        await apiFetch('/api/incidents/resolve', {
          method: 'POST',
          body: JSON.stringify({ incidentId, ...form, timeToFix: Number(form.timeToFix), qaChecks, resolve })
        })
        onSaved()
      } catch (err) {
        setError((err as Error).message)
      }
    })
  }

  const qaComplete = qaChecks.length === QA_CHECKLIST.length

  return (
    <form onSubmit={handleSubmit} className="card animate-in flex flex-col gap-4 border-[#0ea5e9]/60" aria-labelledby="resolution-heading">
      <div>
        <h3 id="resolution-heading" className="text-sm font-semibold">Add a solution</h3>
        <p className="text-xs text-[#94a3b8]">Write it for the next person who hits this — they&apos;ll see it as a suggested fix.</p>
      </div>

      <div>
        <label htmlFor="rootCause" className="field-label">Root cause</label>
        <textarea id="rootCause" className="input" rows={2} required value={form.rootCause}
          placeholder="Why did it actually happen?" onChange={e => update('rootCause', e.target.value)} />
      </div>

      <div>
        <label htmlFor="approach" className="field-label">What fixed it</label>
        <textarea id="approach" className="input" rows={3} required value={form.approach}
          placeholder="Concrete steps, commands, config changes…" onChange={e => update('approach', e.target.value)} />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="timeToFix" className="field-label">Time to fix (minutes)</label>
          <input id="timeToFix" type="number" min={0} step={1} inputMode="numeric" className="input" required
            value={form.timeToFix} onChange={e => update('timeToFix', e.target.value)} placeholder="e.g., 45" />
          <div className="mt-1.5 flex flex-wrap gap-1">
            {TIME_PRESETS.map(m => (
              <button key={m} type="button" className="btn btn-ghost btn-sm !min-h-0 !px-2 !py-0.5 text-[11px]"
                onClick={() => update('timeToFix', String(m))}>
                {m < 60 ? `${m}m` : `${m / 60}h`}
              </button>
            ))}
          </div>
        </div>
        <div>
          <span className="field-label" id="efficiency-label">Kind of fix</span>
          <Segmented
            label="Kind of fix"
            options={EFFICIENCIES}
            value={form.efficiency}
            onChange={v => update('efficiency', v)}
            renderLabel={v => EFFICIENCY_LABEL[v]}
          />
        </div>
      </div>

      <div>
        <label htmlFor="useCaseNotes" className="field-label">When to use this fix</label>
        <textarea id="useCaseNotes" className="input" rows={2} required value={form.useCaseNotes}
          placeholder="Conditions where it applies, and when it won't help"
          onChange={e => update('useCaseNotes', e.target.value)} />
      </div>

      <fieldset className="rounded-md border border-[#475569] bg-[#0f172a]/40 p-3">
        <legend className="px-1 text-xs font-semibold text-[#cbd5e1]">
          QA checklist <span className="font-normal text-[#94a3b8]">({qaChecks.length}/{QA_CHECKLIST.length})</span>
        </legend>
        <div className="flex flex-col gap-1">
          {QA_CHECKLIST.map(item => (
            <label key={item.id} className="flex cursor-pointer items-start gap-2.5 rounded px-1 py-1.5 text-[13px] text-[#cbd5e1] hover:bg-[#334155]/50">
              <input type="checkbox" className="mt-0.5 h-4 w-4 shrink-0 accent-[#0ea5e9]"
                checked={qaChecks.includes(item.id)} onChange={() => toggleCheck(item.id)} />
              {item.label}
            </label>
          ))}
        </div>
        {!qaComplete && (
          <p className="mt-2 text-xs text-[#fcd34d]">
            You can save with open items — they show on the solution so others know what wasn&apos;t checked.
          </p>
        )}
      </fieldset>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:items-end">
        <div>
          <label htmlFor="solvedBy" className="field-label">Solved by</label>
          <input id="solvedBy" className="input" required value={form.solvedBy} autoComplete="name"
            onChange={e => update('solvedBy', e.target.value)} />
        </div>
        {!alreadyResolved && (
          <label className="flex cursor-pointer items-center gap-2 pb-2 text-[13px] text-[#cbd5e1]">
            <input type="checkbox" className="h-4 w-4 accent-[#0ea5e9]" checked={resolve} onChange={e => setResolve(e.target.checked)} />
            Mark incident as resolved
          </label>
        )}
      </div>

      {error && <ErrorNotice message={error} />}

      <div className="flex flex-col gap-2 sm:flex-row">
        <button type="submit" className="btn btn-primary flex-1" disabled={isPending}>
          {isPending ? 'Saving…' : resolve ? 'Save solution & resolve' : 'Save solution'}
        </button>
        <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={isPending}>Cancel</button>
      </div>
    </form>
  )
}
