import Link from 'next/link'

export default function AppHeader({ compact = false }: { compact?: boolean }) {
  return (
    <header className={compact ? 'mb-6 px-4 sm:px-6' : 'mb-8 px-4 sm:px-6'}>
      <Link href="/" className="inline-block">
        <span className={`text-gradient font-extrabold ${compact ? 'text-xl' : 'text-2xl sm:text-[32px]'} leading-tight`}>
          Incident Tracker
        </span>
      </Link>
      {!compact && (
        <p className="mt-1 text-sm text-[#94a3b8]">Reduce recurring issues by learning from past incidents</p>
      )}
    </header>
  )
}
