'use client'

import Link from 'next/link'
import { useEffect, useState, useTransition } from 'react'
import clsx from 'clsx'
import { SEVERITIES, SEVERITY_LABEL, SYSTEM_OPTIONS } from '@/lib/constants'
import type { IncidentSummary, SimilarIncident } from '@/lib/types'
import { apiFetch, useRememberedReporter } from '@/hooks/useIncidents'
import {
  ErrorNotice, formatMinutes, IdTag, SeverityBadge, SolutionStatusBadge, StatusBadge, SystemTag, timeAgo
} from '@/components/ui'

const EMPTY_FORM = {
  title: '',
  description: '',
  symptoms: '',
  affectedSystems: [] as string[],
  severity: 'P2',
  createdBy: '',
  email: ''
}

type Outcome =
  | { kind: 'linked'; originalTitle: string; ownerName: string; notified: boolean }
  | { kind: 'new' }

export default function IncidentForm() {
  const reporter = useRememberedReporter()
  const [formData, setFormData] = useState(EMPTY_FORM)
  const [created, setCreated] = useState<IncidentSummary | null>(null)
  const [similar, setSimilar] = useState<SimilarIncident[]>([])
  const [dismissed, setDismissed] = useState<string[]>([])
  const [outcome, setOutcome] = useState<Outcome | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isPending, startTransition] = useTransition()

  // Prefill reporter details once they load from local storage
  useEffect(() => {
    if (!reporter.name && !reporter.email) return
    setFormData(prev =>
      prev.createdBy || prev.email ? prev : { ...prev, createdBy: reporter.name, email: reporter.email }
    )
  }, [reporter.name, reporter.email])

  const update = <K extends keyof typeof EMPTY_FORM>(key: K, value: (typeof EMPTY_FORM)[K]) =>
    setFormData(prev => ({ ...prev, [key]: value }))

  const toggleSystem = (system: string) =>
    update(
      'affectedSystems',
      formData.affectedSystems.includes(system)
        ? formData.affectedSystems.filter(s => s !== system)
        : [...formData.affectedSystems, system]
    )

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    startTransition(async () => {
      try {
        const data = await apiFetch<{ incident: IncidentSummary; similarIncidents: SimilarIncident[] }>(
          '/api/incidents/create',
          { method: 'POST', body: JSON.stringify(formData) }
        )
        reporter.setReporter(formData.createdBy, formData.email)
        setCreated(data.incident)
        setSimilar(data.similarIncidents)
        setDismissed([])
        if (data.similarIncidents.length === 0) setOutcome({ kind: 'new' })
      } catch (err) {
        setError((err as Error).message)
      }
    })
  }

  const startOver = () => {
    setFormData({ ...EMPTY_FORM, createdBy: formData.createdBy, email: formData.email })
    setCreated(null)
    setSimilar([])
    setOutcome(null)
    setError(null)
  }

  if (created && outcome) {
    return <OutcomePanel incident={created} outcome={outcome} onReportAnother={startOver} />
  }

  if (created) {
    const remaining = similar.filter(s => !dismissed.includes(s.id))
    return (
      <section className="animate-in max-w-[720px]" aria-labelledby="matches-heading">
        <div className="mb-6">
          <p className="mb-2 flex items-center gap-2 text-xs text-[#94a3b8]">
            <span className="badge badge-success">Logged</span>
            {created.title} <IdTag id={created.id} />
          </p>
          <h2 id="matches-heading" className="section-title mb-1">
            {similar.length === 1 ? 'We found 1 similar past incident' : `We found ${similar.length} similar past incidents`}
          </h2>
          <p className="text-[13px] text-[#cbd5e1]">
            If one of these is the same problem, link it — you get its fixes, and its owner is asked to help.
          </p>
        </div>

        <div className="flex flex-col gap-4">
          {similar.map(incident => (
            <IncidentMatch
              key={incident.id}
              incident={incident}
              newIncidentId={created.id}
              dismissed={dismissed.includes(incident.id)}
              onDismiss={() => setDismissed(d => [...d, incident.id])}
              onRestore={() => setDismissed(d => d.filter(id => id !== incident.id))}
              onLinked={result => setOutcome({ kind: 'linked', originalTitle: incident.title, ...result })}
            />
          ))}
        </div>

        <div className="mt-6 flex flex-col gap-3 border-t border-[#475569] pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-[#94a3b8]">
            {remaining.length === 0 ? 'You ruled out every suggestion.' : 'Not seeing your issue?'}
          </p>
          <button type="button" className="btn btn-secondary" onClick={() => setOutcome({ kind: 'new' })}>
            None of these match — keep as a new incident
          </button>
        </div>
      </section>
    )
  }

  return (
    <section aria-labelledby="report-heading">
      <div className="mb-6">
        <h2 id="report-heading" className="mb-1 text-xl font-bold">Report an incident</h2>
        <p className="text-[13px] text-[#cbd5e1]">
          Describe what you see. We&apos;ll check it against past incidents before anyone starts from scratch.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="flex max-w-[640px] flex-col gap-4">
        <div>
          <label htmlFor="title" className="field-label">Incident title</label>
          <input
            id="title"
            className="input"
            placeholder="e.g., Database connection timeout on checkout"
            value={formData.title}
            onChange={e => update('title', e.target.value)}
            maxLength={255}
            required
          />
        </div>

        <div>
          <label htmlFor="description" className="field-label">Description</label>
          <textarea
            id="description"
            className="input"
            placeholder="What happened? When did you first notice it?"
            value={formData.description}
            onChange={e => update('description', e.target.value)}
            rows={3}
            required
          />
        </div>

        <div>
          <label htmlFor="symptoms" className="field-label">Observable symptoms</label>
          <textarea
            id="symptoms"
            className="input"
            placeholder="Error messages, slow responses, what users saw…"
            value={formData.symptoms}
            onChange={e => update('symptoms', e.target.value)}
            rows={3}
            required
            aria-describedby="symptoms-hint"
          />
          <p id="symptoms-hint" className="field-hint">Exact error text gives the best matches.</p>
        </div>

        <fieldset>
          <legend className="field-label">Affected systems</legend>
          <div className="grid grid-cols-2 gap-2 min-[420px]:grid-cols-4">
            {SYSTEM_OPTIONS.map(system => (
              <button
                key={system}
                type="button"
                className="chip"
                aria-pressed={formData.affectedSystems.includes(system)}
                onClick={() => toggleSystem(system)}
              >
                {system}
              </button>
            ))}
          </div>
        </fieldset>

        <fieldset>
          <legend className="field-label">Severity</legend>
          <div role="radiogroup" aria-label="Severity" className="flex flex-wrap gap-2">
            {SEVERITIES.map(severity => (
              <button
                key={severity}
                type="button"
                role="radio"
                aria-checked={formData.severity === severity}
                className={clsx(
                  'chip',
                  formData.severity === severity && severity === 'P1' && '!border-[#ef4444] !bg-[#ef4444] !text-[#0f172a]'
                )}
                onClick={() => update('severity', severity)}
              >
                {SEVERITY_LABEL[severity]}
              </button>
            ))}
          </div>
        </fieldset>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="createdBy" className="field-label">Your name</label>
            <input
              id="createdBy"
              className="input"
              placeholder="Name"
              autoComplete="name"
              value={formData.createdBy}
              onChange={e => update('createdBy', e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="email" className="field-label">Email</label>
            <input
              id="email"
              type="email"
              className="input"
              placeholder="you@company.com"
              autoComplete="email"
              value={formData.email}
              onChange={e => update('email', e.target.value)}
              required
            />
          </div>
        </div>

        {error && <ErrorNotice message={error} />}

        <button type="submit" className="btn btn-primary mt-2 w-full py-3" disabled={isPending}>
          {isPending ? 'Logging and checking for matches…' : 'Report incident & check for matches'}
        </button>
      </form>
    </section>
  )
}

/* ---------- Similar incident card ---------- */

interface IncidentMatchProps {
  incident: SimilarIncident
  newIncidentId: string
  dismissed: boolean
  onDismiss: () => void
  onRestore: () => void
  onLinked: (result: { ownerName: string; notified: boolean }) => void
}

function IncidentMatch({ incident, newIncidentId, dismissed, onDismiss, onRestore, onLinked }: IncidentMatchProps) {
  const [choosing, setChoosing] = useState(false)

  if (dismissed) {
    return (
      <div className="card card-compact flex items-center justify-between gap-3 opacity-60">
        <p className="truncate text-[13px] text-[#94a3b8]">
          <span className="line-through">{incident.title}</span> — marked as a different issue
        </p>
        <button type="button" className="btn btn-ghost btn-sm shrink-0" onClick={onRestore}>Undo</button>
      </div>
    )
  }

  const bestSolution = incident.solutions[0]

  return (
    <article className="card card-interactive animate-in" aria-label={incident.title}>
      <header className="mb-2 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="text-sm font-semibold text-[#f1f5f9]">
            <Link href={`/incidents/${incident.id}`} target="_blank" className="hover:text-[#7dd3fc] hover:underline">
              {incident.title}
            </Link>
          </h3>
          <p className="mt-0.5 text-xs text-[#94a3b8]">
            Reported by <span className="font-medium text-[#cbd5e1]">{incident.createdBy}</span> · {timeAgo(incident.createdAt)}
          </p>
        </div>
        <div className="flex shrink-0 flex-wrap justify-end gap-1.5">
          <SeverityBadge severity={incident.severity} />
          <StatusBadge status={incident.status} />
        </div>
      </header>

      <p className="mb-3 line-clamp-3 max-w-[70ch] text-[13px] leading-relaxed text-[#cbd5e1]">
        <span className="font-semibold text-[#94a3b8]">Symptoms: </span>
        {incident.symptoms}
      </p>

      <div className="mb-3 flex flex-wrap items-center gap-1.5">
        {incident.sharedTerms.length > 0 && <span className="text-[11px] text-[#94a3b8]">Shared terms:</span>}
        {incident.sharedTerms.map(term => (
          <span key={term} className="badge badge-info font-mono">{term}</span>
        ))}
        {incident.affectedSystems.map(s => (
          <SystemTag key={s} system={s} highlight={incident.sharedSystems.includes(s)} />
        ))}
        {incident.recurrences > 0 && (
          <span className="badge badge-warning">↻ Recurred {incident.recurrences}×</span>
        )}
      </div>

      {bestSolution ? (
        <div className="mb-3 rounded-md border border-[#10b981]/30 bg-[#10b981]/5 px-3 py-2">
          <p className="mb-1 flex flex-wrap items-center gap-2 text-xs font-semibold text-[#6ee7b7]">
            {incident.solutions.length === 1 ? '1 known fix' : `${incident.solutions.length} known fixes`}
            <SolutionStatusBadge status={bestSolution.status} />
            <span className="font-normal text-[#94a3b8]">took {formatMinutes(bestSolution.timeToFix)}</span>
          </p>
          <p className="line-clamp-2 text-xs leading-relaxed text-[#cbd5e1]">{bestSolution.approach}</p>
        </div>
      ) : (
        <p className="mb-3 text-xs text-[#94a3b8]">No fix recorded yet — linking still alerts its owner.</p>
      )}

      {!choosing ? (
        <div className="flex flex-col gap-2 sm:flex-row">
          <button type="button" className="btn btn-primary btn-sm flex-1" onClick={() => setChoosing(true)}>
            Yes, this is my issue
          </button>
          <button type="button" className="btn btn-secondary btn-sm flex-1" onClick={onDismiss}>
            Different issue
          </button>
        </div>
      ) : (
        <LinkConfirmation
          incident={incident}
          newIncidentId={newIncidentId}
          onCancel={() => setChoosing(false)}
          onLinked={onLinked}
        />
      )}
    </article>
  )
}

function LinkConfirmation({
  incident,
  newIncidentId,
  onCancel,
  onLinked
}: {
  incident: SimilarIncident
  newIncidentId: string
  onCancel: () => void
  onLinked: IncidentMatchProps['onLinked']
}) {
  const [matchType, setMatchType] = useState<'SAME' | 'SIMILAR'>('SAME')
  const [solutionUsed, setSolutionUsed] = useState('')
  const [notes, setNotes] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [isPending, startTransition] = useTransition()

  const handleLink = () => {
    setError(null)
    startTransition(async () => {
      try {
        const result = await apiFetch<{ notified: boolean; ownerName: string }>('/api/incidents/link', {
          method: 'POST',
          body: JSON.stringify({
            newIncidentId,
            originalIncidentId: incident.id,
            matchType,
            solutionUsed: solutionUsed || undefined,
            notes: notes || undefined
          })
        })
        onLinked(result)
      } catch (err) {
        setError((err as Error).message)
      }
    })
  }

  return (
    <div className="animate-in flex flex-col gap-3 border-t border-[#475569] pt-3">
      <div role="radiogroup" aria-label="How closely does it match?" className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {([
          ['SAME', 'Same issue', 'Group it under this incident'],
          ['SIMILAR', 'Related, not identical', 'Reference it, keep separate']
        ] as const).map(([value, label, hint]) => (
          <button
            key={value}
            type="button"
            role="radio"
            aria-checked={matchType === value}
            onClick={() => setMatchType(value)}
            className={clsx(
              'rounded-md border px-3 py-2 text-left transition-all duration-200 active:scale-[0.98]',
              matchType === value
                ? 'border-[#0ea5e9] bg-[#0ea5e9]/10'
                : 'border-[#475569] bg-[#334155] hover:border-[#0ea5e9]'
            )}
          >
            <span className="block text-xs font-semibold text-[#f1f5f9]">{label}</span>
            <span className="block text-[11px] text-[#94a3b8]">{hint}</span>
          </button>
        ))}
      </div>

      {incident.solutions.length > 0 && (
        <div>
          <label htmlFor={`sol-${incident.id}`} className="field-label">Fix you&apos;ll try first (optional)</label>
          <select
            id={`sol-${incident.id}`}
            className="input"
            value={solutionUsed}
            onChange={e => setSolutionUsed(e.target.value)}
          >
            <option value="">Not decided yet</option>
            {incident.solutions.map(s => (
              <option key={s.id} value={s.id}>
                {s.status === 'VERIFIED' ? '✓ ' : ''}{s.approach.slice(0, 80)}{s.approach.length > 80 ? '…' : ''}
              </option>
            ))}
          </select>
        </div>
      )}

      <div>
        <label htmlFor={`notes-${incident.id}`} className="field-label">Note for {incident.createdBy} (optional)</label>
        <textarea
          id={`notes-${incident.id}`}
          className="input"
          rows={2}
          placeholder="What's different this time?"
          value={notes}
          onChange={e => setNotes(e.target.value)}
        />
      </div>

      <p className="text-xs text-[#94a3b8]">
        {incident.createdBy} will get an email asking them to take a look.
      </p>

      {error && <ErrorNotice message={error} />}

      <div className="flex flex-col gap-2 sm:flex-row">
        <button type="button" className="btn btn-success btn-sm flex-1" onClick={handleLink} disabled={isPending}>
          {isPending ? 'Linking…' : 'Link & notify owner'}
        </button>
        <button type="button" className="btn btn-ghost btn-sm" onClick={onCancel} disabled={isPending}>
          Back
        </button>
      </div>
    </div>
  )
}

/* ---------- Final state ---------- */

function OutcomePanel({
  incident,
  outcome,
  onReportAnother
}: {
  incident: IncidentSummary
  outcome: Outcome
  onReportAnother: () => void
}) {
  return (
    <section role="status" className="card animate-in max-w-[640px] border-[#10b981]/50">
      <p className="mb-1 text-xs font-semibold text-[#6ee7b7]">
        {outcome.kind === 'linked' ? '✓ Linked to a past incident' : '✓ Logged as a new incident'}
      </p>
      <h2 className="mb-2 text-base font-bold">{incident.title}</h2>
      <p className="mb-4 max-w-[60ch] text-[13px] leading-relaxed text-[#cbd5e1]">
        {outcome.kind === 'linked' ? (
          <>
            Linked to <span className="font-semibold text-[#f1f5f9]">{outcome.originalTitle}</span>.{' '}
            {outcome.notified
              ? `${outcome.ownerName} has been notified and can share what worked last time.`
              : `${outcome.ownerName} was not emailed (you reported both, or they were already notified).`}
          </>
        ) : (
          'No earlier incident matched, so this one starts a new record. Once it is fixed, add the solution so the next person finds it.'
        )}
      </p>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Link href={`/incidents/${incident.id}`} className="btn btn-primary">
          Open incident
        </Link>
        <button type="button" className="btn btn-secondary" onClick={onReportAnother}>
          Report another
        </button>
      </div>
    </section>
  )
}
