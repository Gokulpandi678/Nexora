'use client'

import Link from 'next/link'
import { SEVERITIES, SEVERITY_LABEL, STATUSES, STATUS_LABEL } from '@/lib/constants'
import { useStats } from '@/hooks/useIncidents'
import { EmptyState, ErrorNotice, formatMinutes, SeverityBadge, SkeletonCards, StatusBadge } from '@/components/ui'

export default function PatternsDashboard() {
  const { stats, loading, error, refresh } = useStats()

  if (error) return <ErrorNotice message={error} onRetry={refresh} />
  if (loading || !stats) return <SkeletonCards count={4} />
  if (stats.total === 0) {
    return <EmptyState title="No patterns yet">Patterns appear once incidents are reported and linked.</EmptyState>
  }

  const open = (stats.byStatus.OPEN ?? 0) + (stats.byStatus.INVESTIGATING ?? 0)
  const recurrenceRate = Math.round((stats.totalLinks / stats.total) * 100)

  return (
    <section aria-labelledby="patterns-heading" className="flex flex-col gap-6">
      <h2 id="patterns-heading" className="sr-only">Incident patterns</h2>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatTile label="Unresolved" value={open} sub={`of ${stats.total} total`} />
        <StatTile label="Recurrence links" value={stats.totalLinks} sub={`${recurrenceRate}% of reports matched history`} />
        <StatTile
          label="Avg. time to fix"
          value={stats.avgTimeToFix !== null ? formatMinutes(stats.avgTimeToFix) : '—'}
          sub={`across ${stats.totalSolutions} solution${stats.totalSolutions === 1 ? '' : 's'}`}
        />
        <StatTile
          label="Verified fixes"
          value={`${stats.verifiedSolutions}/${stats.totalSolutions}`}
          sub="confirmed on a recurrence"
        />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="card">
          <h3 className="mb-1 text-sm font-semibold">Most recurring incidents</h3>
          <p className="mb-3 text-xs text-[#94a3b8]">Prime candidates for a permanent fix</p>
          {stats.recurring.length === 0 ? (
            <p className="text-[13px] text-[#94a3b8]">No incident has been linked as a recurrence yet.</p>
          ) : (
            <ol className="flex flex-col gap-1">
              {stats.recurring.map(r => (
                <li key={r.id}>
                  <Link
                    href={`/incidents/${r.id}`}
                    className="-mx-2 flex items-center justify-between gap-3 rounded-md px-2 py-1.5 transition-colors hover:bg-[#334155]"
                  >
                    <span className="flex min-w-0 items-center gap-2">
                      <SeverityBadge severity={r.severity} />
                      <span className="truncate text-[13px] text-[#f1f5f9]">{r.title}</span>
                    </span>
                    <span className="flex shrink-0 items-center gap-2">
                      <StatusBadge status={r.status} />
                      <span className="w-8 text-right font-mono text-xs font-semibold text-[#fcd34d]">{r.count}×</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ol>
          )}
        </div>

        <div className="card">
          <h3 className="mb-1 text-sm font-semibold">Incidents by affected system</h3>
          <p className="mb-3 text-xs text-[#94a3b8]">An incident can touch several systems</p>
          <BarList rows={stats.bySystem.map(r => ({ label: r.system, value: r.count }))} unit="incident" />
        </div>

        <div className="card">
          <h3 className="mb-3 text-sm font-semibold">By severity</h3>
          <BarList rows={SEVERITIES.map(s => ({ label: SEVERITY_LABEL[s], value: stats.bySeverity[s] ?? 0 }))} unit="incident" />
        </div>

        <div className="card">
          <h3 className="mb-3 text-sm font-semibold">By status</h3>
          <BarList rows={STATUSES.map(s => ({ label: STATUS_LABEL[s], value: stats.byStatus[s] ?? 0 }))} unit="incident" />
        </div>
      </div>
    </section>
  )
}

function StatTile({ label, value, sub }: { label: string; value: React.ReactNode; sub: string }) {
  return (
    <div className="card card-compact">
      <p className="text-xs font-medium text-[#94a3b8]">{label}</p>
      <p className="my-1 text-2xl font-bold tabular-nums text-[#f1f5f9]">{value}</p>
      <p className="text-[11px] leading-tight text-[#94a3b8]">{sub}</p>
    </div>
  )
}

/** Single-series horizontal bars: one hue, value printed beside each bar, hover shows the exact count. */
function BarList({ rows, unit }: { rows: { label: string; value: number }[]; unit: string }) {
  if (rows.length === 0) return <p className="text-[13px] text-[#94a3b8]">No data yet.</p>
  const max = Math.max(...rows.map(r => r.value), 1)

  return (
    <table className="w-full border-separate border-spacing-y-1.5 text-[13px]">
      <thead className="sr-only">
        <tr><th>Category</th><th>Count</th></tr>
      </thead>
      <tbody>
        {rows.map(row => (
          <tr key={row.label} className="group" title={`${row.label}: ${row.value} ${unit}${row.value === 1 ? '' : 's'}`}>
            <th scope="row" className="w-[1%] whitespace-nowrap pr-3 text-left text-xs font-medium text-[#cbd5e1]">
              {row.label}
            </th>
            <td>
              <div className="flex items-center gap-2">
                <div className="h-3 flex-1 rounded-sm bg-[#334155]/50">
                  <div
                    className="h-3 rounded-r transition-[filter] group-hover:brightness-125"
                    style={{ width: `${(row.value / max) * 100}%`, background: '#0ea5e9', minWidth: row.value ? 4 : 0 }}
                  />
                </div>
                <span className="w-7 text-right font-mono text-xs tabular-nums text-[#cbd5e1]">{row.value}</span>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
