export interface Solution {
  id: string
  incidentId: string
  rootCause: string
  approach: string
  timeToFix: number
  efficiency: string
  useCaseNotes: string
  qaChecks: string[]
  solvedBy: string
  solvedAt: string
  status: string
}

export interface IncidentSummary {
  id: string
  title: string
  description: string
  symptoms: string
  affectedSystems: string[]
  severity: string
  status: string
  createdBy: string
  email: string
  createdAt: string
  resolvedAt: string | null
  linkedToId: string | null
  solutions: Solution[]
  _count?: { matchedFrom: number }
}

export interface SimilarIncident extends IncidentSummary {
  sharedTerms: string[]
  sharedSystems: string[]
  recurrences: number
}

export interface MatchLink {
  id: string
  newIncidentId: string
  originalIncidentId: string
  matchType: string
  solutionUsed: string | null
  notes: string | null
  createdAt: string
}

export interface IncidentDetail extends IncidentSummary {
  linkedTo: IncidentSummary | null
  linkedFrom: IncidentSummary[]
  matchedAs: (MatchLink & { originalIncident: IncidentSummary })[]
  matchedFrom: (MatchLink & { newIncident: IncidentSummary })[]
}

export interface Stats {
  total: number
  byStatus: Record<string, number>
  bySeverity: Record<string, number>
  bySystem: { system: string; count: number }[]
  recurring: { id: string; title: string; severity: string; status: string; count: number }[]
  totalLinks: number
  avgTimeToFix: number | null
  verifiedSolutions: number
  totalSolutions: number
}
