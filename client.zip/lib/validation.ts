import { NextResponse } from 'next/server'

export class ValidationError extends Error {}

export function requireString(body: Record<string, unknown>, key: string, max = 10_000): string {
  const value = body[key]
  if (typeof value !== 'string' || !value.trim()) throw new ValidationError(`"${key}" is required`)
  if (value.length > max) throw new ValidationError(`"${key}" must be at most ${max} characters`)
  return value.trim()
}

export function optionalString(body: Record<string, unknown>, key: string, max = 10_000): string | undefined {
  const value = body[key]
  if (value === undefined || value === null || value === '') return undefined
  if (typeof value !== 'string') throw new ValidationError(`"${key}" must be a string`)
  if (value.length > max) throw new ValidationError(`"${key}" must be at most ${max} characters`)
  return value.trim()
}

export function requireOneOf<T extends string>(
  body: Record<string, unknown>,
  key: string,
  allowed: readonly T[],
  fallback?: T
): T {
  const value = body[key] ?? fallback
  if (typeof value !== 'string' || !allowed.includes(value as T)) {
    throw new ValidationError(`"${key}" must be one of ${allowed.join(', ')}`)
  }
  return value as T
}

export function stringArray(body: Record<string, unknown>, key: string, allowed?: readonly string[]): string[] {
  const value = body[key] ?? []
  if (!Array.isArray(value) || value.some(v => typeof v !== 'string')) {
    throw new ValidationError(`"${key}" must be a list of strings`)
  }
  const unique = [...new Set(value as string[])]
  if (allowed) {
    const bad = unique.find(v => !allowed.includes(v))
    if (bad) throw new ValidationError(`"${bad}" is not a valid ${key} value`)
  }
  return unique
}

export function requireEmail(body: Record<string, unknown>, key: string): string {
  const value = requireString(body, key, 320).toLowerCase()
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) throw new ValidationError(`"${key}" must be a valid email`)
  return value
}

export async function readJson(req: Request): Promise<Record<string, unknown>> {
  try {
    const body = await req.json()
    if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error()
    return body as Record<string, unknown>
  } catch {
    throw new ValidationError('Request body must be a JSON object')
  }
}

export function errorResponse(error: unknown, fallback: string) {
  if (error instanceof ValidationError) {
    return NextResponse.json({ error: error.message }, { status: 400 })
  }
  console.error(fallback, error)
  return NextResponse.json({ error: fallback }, { status: 500 })
}
