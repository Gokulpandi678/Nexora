export const SYSTEM_OPTIONS = ['Database', 'API', 'Cache', 'Network', 'Auth', 'Storage', 'Queue', 'Other'] as const
export const SEVERITIES = ['P1', 'P2', 'P3'] as const
export const STATUSES = ['OPEN', 'INVESTIGATING', 'RESOLVED'] as const
export const EFFICIENCIES = ['LOW', 'MEDIUM', 'HIGH'] as const
export const MATCH_TYPES = ['SAME', 'SIMILAR'] as const

export const SEVERITY_LABEL: Record<string, string> = {
  P1: 'P1 · Critical',
  P2: 'P2 · Major',
  P3: 'P3 · Minor'
}

export const STATUS_LABEL: Record<string, string> = {
  OPEN: 'Open',
  INVESTIGATING: 'Investigating',
  RESOLVED: 'Resolved'
}

export const QA_CHECKLIST = [
  { id: 'root-cause-confirmed', label: 'Root cause confirmed, not just symptoms suppressed' },
  { id: 'fix-verified', label: 'Fix verified in the affected environment' },
  { id: 'monitoring', label: 'Monitoring or alerting covers a recurrence' },
  { id: 'rollback', label: 'Rollback path is known if the fix regresses' },
  { id: 'documented', label: 'Steps are written so someone else can repeat them' }
] as const

export const TABS = [
  { id: 'report', label: '+ Report incident' },
  { id: 'view', label: 'All incidents' },
  { id: 'patterns', label: 'Patterns' }
] as const

export type TabId = (typeof TABS)[number]['id']
