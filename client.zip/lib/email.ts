import { Resend } from 'resend'
import { prisma } from '@/lib/db'

const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null

function escapeHtml(value: string) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

/**
 * Tells the owner of an earlier incident that it has recurred.
 * Deduplicated via NotificationLog so one owner is not mailed twice for the same new incident.
 * Returns true when a notification was sent (or logged, when no email provider is configured).
 */
export async function sendMatchNotification(
  recipientEmail: string,
  incidentTitle: string,
  newIncidentId: string,
  newIncidentTitle: string
): Promise<boolean> {
  const notificationType = 'RECURRENCE'
  const already = await prisma.notificationLog.findFirst({
    where: { recipientEmail, incidentId: newIncidentId, notificationType }
  })
  if (already) return false

  const url = `${process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000'}/incidents/${newIncidentId}`
  const title = escapeHtml(incidentTitle)
  const newTitle = escapeHtml(newIncidentTitle)

  try {
    if (!resend) {
      console.info(`[email disabled] Would notify ${recipientEmail}: "${incidentTitle}" recurred -> ${url}`)
    } else {
      const { error } = await resend.emails.send({
        from: process.env.EMAIL_FROM ?? 'Incident Tracker <alerts@incident-tracker.com>',
        to: recipientEmail,
        subject: `Your incident "${incidentTitle}" is happening again`,
        html: `
          <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #f1f5f9; background: #0f172a; padding: 20px; border-radius: 8px; max-width: 600px; margin: 0 auto;">
            <div style="border-left: 4px solid #0ea5e9; padding-left: 16px; margin-bottom: 20px;">
              <h2 style="margin: 0 0 8px 0; color: #7dd3fc; font-size: 18px;">Incident match alert</h2>
              <p style="margin: 0; color: #cbd5e1; font-size: 14px;">Someone just reported an incident matching one you raised before.</p>
            </div>
            <div style="background: #1e293b; padding: 12px; border-radius: 6px; margin-bottom: 12px; border: 1px solid #475569;">
              <p style="margin: 0 0 6px 0; color: #94a3b8; font-size: 12px;">Your original issue</p>
              <p style="margin: 0; color: #f1f5f9; font-size: 14px; font-weight: 600;">${title}</p>
            </div>
            <div style="background: #1e293b; padding: 12px; border-radius: 6px; margin-bottom: 16px; border: 1px solid #475569;">
              <p style="margin: 0 0 6px 0; color: #94a3b8; font-size: 12px;">New report</p>
              <p style="margin: 0; color: #f1f5f9; font-size: 14px; font-weight: 600;">${newTitle}</p>
            </div>
            <p style="color: #cbd5e1; font-size: 13px; line-height: 1.6;">
              Can you check whether it is the same issue and share what worked last time? Your experience could get this fixed faster.
            </p>
            <a href="${url}" style="display: inline-block; background: #0ea5e9; color: #0f172a; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 14px; margin-top: 12px;">
              Review the new incident &rarr;
            </a>
            <p style="margin: 20px 0 0 0; padding-top: 16px; border-top: 1px solid #475569; color: #94a3b8; font-size: 12px;">
              Incident Tracker
            </p>
          </div>
        `
      })
      if (error) throw new Error(error.message)
    }

    await prisma.notificationLog.create({
      data: { recipientEmail, incidentId: newIncidentId, notificationType }
    })
    return true
  } catch (error) {
    console.error('Error sending email:', error)
    return false
  }
}
