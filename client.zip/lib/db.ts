import { Prisma, PrismaClient } from '@prisma/client'

// Reuse one client across hot reloads in dev
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient }
export const prisma = globalForPrisma.prisma ?? new PrismaClient()
if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma

const STOPWORDS = new Set([
  'the', 'and', 'for', 'with', 'from', 'that', 'this', 'was', 'were', 'are', 'has', 'have', 'had',
  'not', 'but', 'when', 'what', 'into', 'our', 'out', 'its', 'after', 'during', 'then', 'than',
  'some', 'all', 'any', 'can', 'could', 'should', 'would', 'been', 'being', 'also', 'very', 'just'
])

/** Lowercase alphanumeric keywords, deduped, stopwords removed. */
export function extractTerms(text: string, max = 24): string[] {
  const words = text.toLowerCase().match(/[a-z0-9]+/g) ?? []
  const terms: string[] = []
  for (const w of words) {
    if (w.length < 3 || STOPWORDS.has(w) || terms.includes(w)) continue
    terms.push(w)
    if (terms.length >= max) break
  }
  return terms
}

const incidentText = Prisma.sql`
  to_tsvector('english', coalesce("title", '') || ' ' || coalesce("description", '') || ' ' || coalesce("symptoms", ''))
`

interface SimilarOptions {
  limit?: number
  excludeId?: string
  systems?: string[]
}

/**
 * Ranks past incidents by Postgres full-text relevance against any of the query's keywords
 * (OR semantics, so partial overlaps still surface), with a boost for shared affected systems.
 */
export async function searchSimilarIncidents(query: string, { limit = 5, excludeId, systems = [] }: SimilarOptions = {}) {
  const terms = extractTerms(query)
  if (terms.length === 0) return []

  const tsquery = terms.join(' | ')
  // A single incidental word hit (e.g. "show" stemming onto "showed") is noise, so require
  // two distinct matching terms, or one term plus a shared affected system
  const minHits = terms.length < 3 ? 1 : 2
  const ranked = await prisma.$queryRaw<{ id: string; score: number }[]>`
    WITH candidates AS (
      SELECT "id", "createdAt",
        ts_rank_cd(${incidentText}, to_tsquery('english', ${tsquery})) AS rank,
        (SELECT count(*) FROM unnest(${terms}::text[]) AS t(term)
          WHERE ${incidentText} @@ plainto_tsquery('english', t.term)) AS hits,
        cardinality(ARRAY(SELECT unnest("affectedSystems") INTERSECT SELECT unnest(${systems}::text[]))) AS shared
      FROM "Incident"
      WHERE ${incidentText} @@ to_tsquery('english', ${tsquery})
        AND "id" <> ${excludeId ?? ''}
    )
    SELECT "id", rank + 0.05 * hits + 0.15 * shared AS score
    FROM candidates
    WHERE hits >= ${minHits} OR (hits >= 1 AND shared > 0)
    ORDER BY score DESC, "createdAt" DESC
    LIMIT ${limit}
  `
  if (ranked.length === 0) return []

  const incidents = await prisma.incident.findMany({
    where: { id: { in: ranked.map(r => r.id) } },
    include: {
      solutions: { orderBy: [{ status: 'desc' }, { solvedAt: 'desc' }] },
      _count: { select: { matchedFrom: true } }
    }
  })
  const byId = new Map(incidents.map(i => [i.id, i]))

  return ranked.flatMap(r => {
    const incident = byId.get(r.id)
    if (!incident) return []
    const haystack = new Set(extractTerms(`${incident.title} ${incident.description} ${incident.symptoms}`, 500))
    return [{
      ...incident,
      sharedTerms: terms.filter(t => haystack.has(t)).slice(0, 6),
      sharedSystems: incident.affectedSystems.filter(s => systems.includes(s)),
      recurrences: incident._count.matchedFrom
    }]
  })
}

export async function getIncidentWithDetails(id: string) {
  return prisma.incident.findUnique({
    where: { id },
    include: {
      solutions: { orderBy: [{ status: 'desc' }, { solvedAt: 'desc' }] },
      linkedFrom: { include: { solutions: true }, orderBy: { createdAt: 'desc' } },
      linkedTo: { include: { solutions: true } },
      matchedAs: { include: { originalIncident: { include: { solutions: true } } } },
      matchedFrom: { include: { newIncident: { include: { solutions: true } } }, orderBy: { createdAt: 'desc' } }
    }
  })
}
