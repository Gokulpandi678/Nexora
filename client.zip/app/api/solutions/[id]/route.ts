import { prisma } from '@/lib/db'
import { errorResponse, readJson, requireOneOf } from '@/lib/validation'
import { NextRequest, NextResponse } from 'next/server'

type Params = { params: Promise<{ id: string }> }

/** Marks a solution VERIFIED (it worked again on a recurrence) or back to UNVERIFIED. */
export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    const body = await readJson(req)
    const status = requireOneOf(body, 'status', ['VERIFIED', 'UNVERIFIED'] as const)

    const solution = await prisma.solution.update({ where: { id }, data: { status } })
    return NextResponse.json(solution)
  } catch (error) {
    return errorResponse(error, 'Failed to update solution')
  }
}
