import { prisma, searchSimilarIncidents } from '@/lib/db'
import { SEVERITIES, SYSTEM_OPTIONS } from '@/lib/constants'
import { errorResponse, readJson, requireEmail, requireOneOf, requireString, stringArray } from '@/lib/validation'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const body = await readJson(req)
    const data = {
      title: requireString(body, 'title', 255),
      description: requireString(body, 'description'),
      symptoms: requireString(body, 'symptoms'),
      affectedSystems: stringArray(body, 'affectedSystems', SYSTEM_OPTIONS),
      severity: requireOneOf(body, 'severity', SEVERITIES, 'P2'),
      createdBy: requireString(body, 'createdBy', 120),
      email: requireEmail(body, 'email')
    }

    const incident = await prisma.incident.create({ data: { ...data, status: 'OPEN' } })

    // Title and symptoms carry the strongest signal, so they lead the query
    const similarIncidents = await searchSimilarIncidents(
      `${data.title} ${data.symptoms} ${data.description}`,
      { limit: 5, excludeId: incident.id, systems: data.affectedSystems }
    )

    return NextResponse.json({ incident, similarIncidents }, { status: 201 })
  } catch (error) {
    return errorResponse(error, 'Failed to create incident')
  }
}
