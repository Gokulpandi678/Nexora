import { prisma } from '@/lib/db'
import { SEVERITIES, STATUSES } from '@/lib/constants'
import { errorResponse } from '@/lib/validation'
import { Prisma } from '@prisma/client'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const q = searchParams.get('q')?.trim()
    const status = searchParams.get('status')
    const severity = searchParams.get('severity')
    const system = searchParams.get('system')

    const where: Prisma.IncidentWhereInput = {
      AND: [
        // Substring match so results update sensibly while the user is still typing a word
        q
          ? {
              OR: [
                { title: { contains: q, mode: 'insensitive' } },
                { description: { contains: q, mode: 'insensitive' } },
                { symptoms: { contains: q, mode: 'insensitive' } },
                { createdBy: { contains: q, mode: 'insensitive' } }
              ]
            }
          : {},
        status && (STATUSES as readonly string[]).includes(status) ? { status } : {},
        severity && (SEVERITIES as readonly string[]).includes(severity) ? { severity } : {},
        system ? { affectedSystems: { has: system } } : {}
      ]
    }

    const results = await prisma.incident.findMany({
      where,
      include: {
        solutions: { orderBy: { solvedAt: 'desc' } },
        _count: { select: { matchedFrom: true } }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    })

    return NextResponse.json(results)
  } catch (error) {
    return errorResponse(error, 'Failed to search')
  }
}
