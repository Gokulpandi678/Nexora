import { prisma } from '@/lib/db'
import { EFFICIENCIES, QA_CHECKLIST } from '@/lib/constants'
import { errorResponse, readJson, requireOneOf, requireString, stringArray, ValidationError } from '@/lib/validation'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const body = await readJson(req)
    const incidentId = requireString(body, 'incidentId', 64)
    const timeToFix = Number(body.timeToFix)
    if (!Number.isInteger(timeToFix) || timeToFix < 0 || timeToFix > 525_600) {
      throw new ValidationError('"timeToFix" must be a whole number of minutes')
    }
    const data = {
      rootCause: requireString(body, 'rootCause'),
      approach: requireString(body, 'approach'),
      useCaseNotes: requireString(body, 'useCaseNotes'),
      solvedBy: requireString(body, 'solvedBy', 120),
      efficiency: requireOneOf(body, 'efficiency', EFFICIENCIES, 'MEDIUM'),
      qaChecks: stringArray(body, 'qaChecks', QA_CHECKLIST.map(c => c.id)),
      timeToFix
    }
    const resolve = body.resolve !== false

    const exists = await prisma.incident.findUnique({ where: { id: incidentId }, select: { id: true } })
    if (!exists) return NextResponse.json({ error: 'Incident not found' }, { status: 404 })

    const [solution] = await prisma.$transaction([
      prisma.solution.create({ data: { incidentId, ...data, status: 'UNVERIFIED' } }),
      ...(resolve
        ? [prisma.incident.update({ where: { id: incidentId }, data: { status: 'RESOLVED', resolvedAt: new Date() } })]
        : [])
    ])

    return NextResponse.json({ solution, success: true }, { status: 201 })
  } catch (error) {
    return errorResponse(error, 'Failed to resolve incident')
  }
}
