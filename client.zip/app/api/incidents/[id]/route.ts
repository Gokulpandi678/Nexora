import { getIncidentWithDetails, prisma } from '@/lib/db'
import { STATUSES } from '@/lib/constants'
import { errorResponse, readJson, requireOneOf } from '@/lib/validation'
import { NextRequest, NextResponse } from 'next/server'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    const incident = await getIncidentWithDetails(id)
    if (!incident) return NextResponse.json({ error: 'Incident not found' }, { status: 404 })
    return NextResponse.json(incident)
  } catch (error) {
    return errorResponse(error, 'Failed to load incident')
  }
}

export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    const body = await readJson(req)
    const status = requireOneOf(body, 'status', STATUSES)

    const incident = await prisma.incident.update({
      where: { id },
      data: { status, resolvedAt: status === 'RESOLVED' ? new Date() : null }
    })
    return NextResponse.json(incident)
  } catch (error) {
    return errorResponse(error, 'Failed to update incident')
  }
}
