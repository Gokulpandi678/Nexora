import { prisma } from '@/lib/db'
import { sendMatchNotification } from '@/lib/email'
import { MATCH_TYPES } from '@/lib/constants'
import { errorResponse, optionalString, readJson, requireOneOf, requireString, ValidationError } from '@/lib/validation'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const body = await readJson(req)
    const newIncidentId = requireString(body, 'newIncidentId', 64)
    const originalIncidentId = requireString(body, 'originalIncidentId', 64)
    const matchType = requireOneOf(body, 'matchType', MATCH_TYPES, 'SAME')
    const solutionUsed = optionalString(body, 'solutionUsed', 64)
    const notes = optionalString(body, 'notes')

    if (newIncidentId === originalIncidentId) throw new ValidationError('An incident cannot be linked to itself')

    const [newIncident, original] = await Promise.all([
      prisma.incident.findUnique({ where: { id: newIncidentId } }),
      prisma.incident.findUnique({ where: { id: originalIncidentId } })
    ])
    if (!newIncident || !original) {
      return NextResponse.json({ error: 'Incident not found' }, { status: 404 })
    }
    if (solutionUsed) {
      const solution = await prisma.solution.findFirst({ where: { id: solutionUsed, incidentId: originalIncidentId } })
      if (!solution) throw new ValidationError('Selected solution does not belong to the original incident')
    }

    // Point at the root of the chain so recurrences group under one original
    const rootId = original.linkedToId ?? original.id

    const link = await prisma.$transaction(async tx => {
      const link = await tx.matchLink.upsert({
        where: { newIncidentId_originalIncidentId: { newIncidentId, originalIncidentId } },
        create: { newIncidentId, originalIncidentId, matchType, solutionUsed, notes },
        update: { matchType, solutionUsed, notes }
      })
      if (matchType === 'SAME' && rootId !== newIncidentId) {
        await tx.incident.update({ where: { id: newIncidentId }, data: { linkedToId: rootId } })
      }
      return link
    })

    const notified = original.email !== newIncident.email
      ? await sendMatchNotification(original.email, original.title, newIncident.id, newIncident.title)
      : false

    return NextResponse.json({ success: true, link, notified, ownerName: original.createdBy })
  } catch (error) {
    return errorResponse(error, 'Failed to link incident')
  }
}
