import { prisma } from '@/lib/db'
import { errorResponse } from '@/lib/validation'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const [byStatus, bySeverity, bySystem, recurringGroups, totalLinks, solutionAgg, verifiedSolutions] =
      await Promise.all([
        prisma.incident.groupBy({ by: ['status'], _count: { _all: true } }),
        prisma.incident.groupBy({ by: ['severity'], _count: { _all: true } }),
        prisma.$queryRaw<{ system: string; count: bigint }[]>`
          SELECT unnest("affectedSystems") AS system, COUNT(*) AS count
          FROM "Incident" GROUP BY system ORDER BY count DESC
        `,
        prisma.matchLink.groupBy({
          by: ['originalIncidentId'],
          _count: { _all: true },
          orderBy: { _count: { originalIncidentId: 'desc' } },
          take: 5
        }),
        prisma.matchLink.count(),
        prisma.solution.aggregate({ _avg: { timeToFix: true }, _count: { _all: true } }),
        prisma.solution.count({ where: { status: 'VERIFIED' } })
      ])

    const recurringIncidents = await prisma.incident.findMany({
      where: { id: { in: recurringGroups.map(g => g.originalIncidentId) } },
      select: { id: true, title: true, severity: true, status: true }
    })
    const recurring = recurringGroups.flatMap(g => {
      const incident = recurringIncidents.find(i => i.id === g.originalIncidentId)
      return incident ? [{ ...incident, count: g._count._all }] : []
    })

    const toRecord = (rows: { _count: { _all: number } }[], key: 'status' | 'severity') =>
      Object.fromEntries(rows.map(r => [(r as unknown as Record<string, string>)[key], r._count._all]))

    return NextResponse.json({
      total: byStatus.reduce((sum, r) => sum + r._count._all, 0),
      byStatus: toRecord(byStatus, 'status'),
      bySeverity: toRecord(bySeverity, 'severity'),
      bySystem: bySystem.map(r => ({ system: r.system, count: Number(r.count) })),
      recurring,
      totalLinks,
      avgTimeToFix: solutionAgg._avg.timeToFix ? Math.round(solutionAgg._avg.timeToFix) : null,
      totalSolutions: solutionAgg._count._all,
      verifiedSolutions
    })
  } catch (error) {
    return errorResponse(error, 'Failed to load stats')
  }
}
