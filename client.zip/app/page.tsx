import Dashboard from '@/components/Dashboard'
import { TABS, type TabId } from '@/lib/constants'

export default async function Home({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const { tab } = await searchParams
  const initialTab: TabId = TABS.some(t => t.id === tab) ? (tab as TabId) : 'report'

  return <Dashboard initialTab={initialTab} />
}
