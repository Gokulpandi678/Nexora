import Link from 'next/link'
import AppHeader from '@/components/AppHeader'
import IncidentDetail from '@/components/IncidentDetail'

export default async function IncidentPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  return (
    <div className="mx-auto max-w-[1200px] pb-10 pt-5">
      <AppHeader compact />
      <div className="px-4 sm:px-6">
        <nav className="mb-4" aria-label="Breadcrumb">
          <Link href="/?tab=view" className="btn btn-ghost btn-sm -ml-3">← All incidents</Link>
        </nav>
        <IncidentDetail id={id} />
      </div>
    </div>
  )
}
